"""
Jupyter Notebook Table of Contents Generator
"""

__version__ = "0.1.0"
from .core import generate_toc

__all__ = ["generate_toc"] 